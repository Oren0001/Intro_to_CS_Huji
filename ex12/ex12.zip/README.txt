Play button - Starts the game.

Magnifying glass button - After the player chose the word, this button searches it in the dictionary.

Refresh button - Allows the player to refresh the board.

New button - Starts a new game.