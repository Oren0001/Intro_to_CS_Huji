##########################################################################
# FILE : hello_turtle.py
# WRITER : Oren Motiei , oren503, 321174591
# EXERCISE : intro2cs2 ex1 2020
# DESCRIPTION: Function that prints the string from the automatic tests.
# STUDENTS I DISCUSSED THE EXERCISE WITH: None.
# WEB PAGES I USED: None.
# NOTES: None.
##########################################################################

def secret_function():
    """Prints the asked string from the automatic tests"""
    print("My username is oren503 and I realize that not checking the "
          "submission response can have consequences for my grade.")
